library IEEE;
use IEEE.std_logic_1164.all;

entity lab4 is
    port (
        CLK   : in  STD_LOGIC;
        Reset : in  STD_LOGIC;
        Z     : in  STD_LOGIC_VECTOR (1 to 4);   -- логічні умови Z1..Z4
        Y     : out STD_LOGIC_VECTOR (0 to 2)    -- код стану (номер вершини)
    );
end lab4;

architecture lab4 of lab4 is

-- стани автомата Мура
type Sreg0_type is (q0, q1, q2, q3, q4, q5);
signal Sreg0, NextState_Sreg0 : Sreg0_type;

begin

----------------------------------------------------------------------
-- регістр стану: синхронне скидання в q0 (Reset = '1')
----------------------------------------------------------------------
Sreg0_machine : process (CLK)
begin
    if CLK'event and CLK = '1' then
        if Reset = '1' then
            Sreg0 <= q0;
        else
            Sreg0 <= NextState_Sreg0;
        end if;
    end if;
end process;

----------------------------------------------------------------------
-- функція переходів
----------------------------------------------------------------------
Sreg0_next : process (Sreg0, Z)
begin
    NextState_Sreg0 <= Sreg0;
    case Sreg0 is
        when q0 =>
            if Z(1) = '0' then
                NextState_Sreg0 <= q1;
            elsif Z(1) = '1' then
                NextState_Sreg0 <= q2;
            end if;
        when q1 =>
            NextState_Sreg0 <= q2;
        when q2 =>
            if Z(2) = '0' then
                NextState_Sreg0 <= q3;
            elsif Z(2) = '1' and Z(4) = '1' then
                NextState_Sreg0 <= q4;
            elsif Z(2) = '1' and Z(4) = '0' then
                NextState_Sreg0 <= q0;
            end if;
        when q3 =>
            NextState_Sreg0 <= q4;
        when q4 =>
            if Z(3) = '1' then
                NextState_Sreg0 <= q1;
            elsif Z(3) = '0' then
                NextState_Sreg0 <= q5;
            end if;
        when q5 =>
            if Z(4) = '1' then
                NextState_Sreg0 <= q4;
            elsif Z(4) = '0' then
                NextState_Sreg0 <= q0;
            end if;
        when others => null;
    end case;
end process;

----------------------------------------------------------------------
-- функція виходів автомата Мура (залежить лише від стану)
----------------------------------------------------------------------
Sreg0_output : process (Sreg0)
begin
    case Sreg0 is
        when q0 => Y <= "000";
        when q1 => Y <= "001";
        when q2 => Y <= "010";
        when q3 => Y <= "011";
        when q4 => Y <= "100";
        when q5 => Y <= "101";
        when others => Y <= "000";
    end case;
end process;

end lab4;
