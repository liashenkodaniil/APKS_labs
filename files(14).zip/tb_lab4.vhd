library IEEE;
use IEEE.std_logic_1164.all;

entity tb_lab4 is
end tb_lab4;

architecture tb of tb_lab4 is
    component lab4 is
        port (
            CLK   : in  STD_LOGIC;
            Reset : in  STD_LOGIC;
            Z     : in  STD_LOGIC_VECTOR (1 to 4);
            Y     : out STD_LOGIC_VECTOR (0 to 2)
        );
    end component;

    signal CLK   : STD_LOGIC := '0';
    signal Reset : STD_LOGIC := '1';
    signal Z     : STD_LOGIC_VECTOR (1 to 4) := "0000";
    signal Y     : STD_LOGIC_VECTOR (0 to 2);
begin
    UUT : lab4 port map (CLK, Reset, Z, Y);

    -- тактовий сигнал: період 10 ns (100 МГц), робочий фронт 5, 15, 25 ... ns
    clk_gen : process
    begin
        CLK <= '0'; wait for 5 ns;
        CLK <= '1'; wait for 5 ns;
    end process;

    stim : process
        procedure step(zv : STD_LOGIC_VECTOR(1 to 4);
                       expected : STD_LOGIC_VECTOR(0 to 2)) is
        begin
            Z <= zv;                          -- умови задаються до робочого фронту
            wait until rising_edge(CLK);
            wait for 1 ns;
            assert Y = expected
                report "Wrong state after transition"
                severity error;
        end procedure;
    begin
        Reset <= '1';
        wait until rising_edge(CLK);          -- синхронне скидання в q0
        wait for 1 ns;
        assert Y = "000" report "Reset: wrong state" severity error;
        Reset <= '0';
        step("1000", "010");   --  1: q0 -> q2   (Z1=1)
        step("0100", "000");   --  2: q2 -> q0   (Z2=1, Z4=0)
        step("0000", "001");   --  3: q0 -> q1   (Z1=0)
        step("0000", "010");   --  4: q1 -> q2
        step("0000", "011");   --  5: q2 -> q3   (Z2=0)
        step("0000", "100");   --  6: q3 -> q4
        step("0000", "101");   --  7: q4 -> q5   (Z3=0)
        step("0001", "100");   --  8: q5 -> q4   (Z4=1)
        step("0010", "001");   --  9: q4 -> q1   (Z3=1)
        step("0000", "010");   -- 10: q1 -> q2
        step("0101", "100");   -- 11: q2 -> q4   (Z2=1, Z4=1)
        step("0000", "101");   -- 12: q4 -> q5   (Z3=0)
        step("0000", "000");   -- 13: q5 -> q0   (Z4=0)
        wait for 20 ns;
        report "Simulation finished" severity note;
        wait;
    end process;
end tb;
